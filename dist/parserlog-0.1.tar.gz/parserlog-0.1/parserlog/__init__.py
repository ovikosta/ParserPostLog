"""
Parser postfix log.
"""

__version__ = '1.0'
